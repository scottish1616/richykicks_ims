import uuid
from decimal import Decimal

from sqlalchemy.orm import Session

from app.models.product import Product
from app.models.sale import Sale
from app.services import audit_service


class ProductNotFoundError(Exception):
    pass


class ProductInactiveError(Exception):
    pass


class InsufficientStockError(Exception):
    def __init__(self, available: int, requested: int):
        self.available = available
        self.requested = requested
        super().__init__(f"Insufficient stock: {available} available, {requested} requested")


def record_sale(
    db: Session,
    staff_id: uuid.UUID,
    product_id: uuid.UUID,
    quantity: int,
    actual_price_paid: Decimal,
) -> Sale:
    product = (
        db.query(Product).filter(Product.id == product_id).with_for_update().first()
    )

    if product is None:
        raise ProductNotFoundError()

    if not product.is_active:
        raise ProductInactiveError()

    if product.stock_quantity < quantity:
        raise InsufficientStockError(available=product.stock_quantity, requested=quantity)

    sale = Sale(
        product_id=product.id,
        staff_id=staff_id,
        quantity=quantity,
        listed_price_at_sale=product.listed_price,
        actual_price_paid=actual_price_paid,
        total_amount=actual_price_paid * quantity,
    )
    product.stock_quantity -= quantity

    try:
        db.add(sale)
        audit_service.log_event(
            db,
            event_type="sale.created",
            user_id=staff_id,
            resource=f"product:{product_id}",
            result="success",
            metadata={
                "quantity": quantity,
                "actual_price_paid": str(actual_price_paid),
                "listed_price_at_sale": str(product.listed_price),
            },
            commit=False,
        )
        db.commit()
    except Exception:
        db.rollback()
        raise

    db.refresh(sale)
    return sale
