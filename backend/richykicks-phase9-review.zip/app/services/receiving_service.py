import uuid
from datetime import datetime, timezone
from decimal import Decimal

from sqlalchemy.orm import Session

from app.models.product import Product
from app.models.stock_receiving import (
    ReceivingItemStatus,
    ReceivingSessionStatus,
    StockReceivingItem,
    StockReceivingSession,
)
from app.services import audit_service


class SessionNotFoundError(Exception):
    pass


class SessionNotOpenError(Exception):
    pass


class SessionNotPendingError(Exception):
    pass


class ItemNotFoundError(Exception):
    pass


class EmptySessionError(Exception):
    pass


def open_session(db: Session, admin_id: uuid.UUID) -> StockReceivingSession:
    session = StockReceivingSession(opened_by=admin_id, status=ReceivingSessionStatus.OPEN)
    db.add(session)
    audit_service.log_event(
        db,
        event_type="receiving.session_opened",
        user_id=admin_id,
        resource=None,
        result="success",
        commit=False,
    )
    db.commit()
    db.refresh(session)
    return session


def _get_session_or_raise(db: Session, session_id: uuid.UUID) -> StockReceivingSession:
    session = db.get(StockReceivingSession, session_id)
    if session is None:
        raise SessionNotFoundError()
    return session


def submit_item(
    db: Session,
    session_id: uuid.UUID,
    staff_id: uuid.UUID,
    product_id: uuid.UUID,
    quantity_submitted: int,
    price_submitted: Decimal,
) -> StockReceivingItem:
    session = _get_session_or_raise(db, session_id)
    if session.status != ReceivingSessionStatus.OPEN:
        raise SessionNotOpenError()

    item = StockReceivingItem(
        session_id=session.id,
        product_id=product_id,
        submitted_by=staff_id,
        quantity_submitted=quantity_submitted,
        price_submitted=price_submitted,
        status=ReceivingItemStatus.PENDING,
    )
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


def submit_session(
    db: Session, session_id: uuid.UUID, actor_id: uuid.UUID | None = None
) -> StockReceivingSession:
    session = _get_session_or_raise(db, session_id)
    if session.status != ReceivingSessionStatus.OPEN:
        raise SessionNotOpenError()

    if len(session.items) == 0:
        raise EmptySessionError()

    session.status = ReceivingSessionStatus.PENDING
    audit_service.log_event(
        db,
        event_type="receiving.session_submitted",
        user_id=actor_id,
        resource=f"session:{session_id}",
        result="success",
        metadata={"item_count": len(session.items)},
        commit=False,
    )
    db.commit()
    db.refresh(session)
    return session


def correct_item(
    db: Session,
    item_id: uuid.UUID,
    quantity_approved: int,
    price_approved: Decimal,
    actor_id: uuid.UUID | None = None,
) -> StockReceivingItem:
    item = db.get(StockReceivingItem, item_id)
    if item is None:
        raise ItemNotFoundError()

    if item.session.status != ReceivingSessionStatus.PENDING:
        raise SessionNotPendingError()

    item.quantity_approved = quantity_approved
    item.price_approved = price_approved
    audit_service.log_event(
        db,
        event_type="receiving.item_corrected",
        user_id=actor_id,
        resource=f"item:{item_id}",
        result="success",
        metadata={
            "quantity_approved": quantity_approved,
            "price_approved": str(price_approved),
        },
        commit=False,
    )
    db.commit()
    db.refresh(item)
    return item


def approve_session(
    db: Session, session_id: uuid.UUID, actor_id: uuid.UUID | None = None
) -> StockReceivingSession:
    session = (
        db.query(StockReceivingSession)
        .filter(StockReceivingSession.id == session_id)
        .with_for_update()
        .first()
    )
    if session is None:
        raise SessionNotFoundError()
    if session.status != ReceivingSessionStatus.PENDING:
        raise SessionNotPendingError()

    try:
        for item in session.items:
            # Default to what Staff submitted if Admin never corrected it.
            approved_qty = (
                item.quantity_approved
                if item.quantity_approved is not None
                else item.quantity_submitted
            )
            approved_price = (
                item.price_approved if item.price_approved is not None else item.price_submitted
            )

            product = (
                db.query(Product).filter(Product.id == item.product_id).with_for_update().first()
            )
            if product is not None:
                product.stock_quantity += approved_qty
                product.listed_price = approved_price

            item.quantity_approved = approved_qty
            item.price_approved = approved_price
            item.status = ReceivingItemStatus.APPROVED

        session.status = ReceivingSessionStatus.APPROVED
        session.closed_at = datetime.now(timezone.utc)

        audit_service.log_event(
            db,
            event_type="receiving.session_approved",
            user_id=actor_id,
            resource=f"session:{session_id}",
            result="success",
            metadata={"item_count": len(session.items)},
            commit=False,
        )

        db.commit()
    except Exception:
        db.rollback()
        raise

    db.refresh(session)
    return session


def reject_session(
    db: Session, session_id: uuid.UUID, actor_id: uuid.UUID | None = None
) -> StockReceivingSession:
    session = _get_session_or_raise(db, session_id)
    if session.status != ReceivingSessionStatus.PENDING:
        raise SessionNotPendingError()

    for item in session.items:
        item.status = ReceivingItemStatus.REJECTED

    session.status = ReceivingSessionStatus.REJECTED
    session.closed_at = datetime.now(timezone.utc)
    audit_service.log_event(
        db,
        event_type="receiving.session_rejected",
        user_id=actor_id,
        resource=f"session:{session_id}",
        result="success",
        commit=False,
    )
    db.commit()
    db.refresh(session)
    return session
