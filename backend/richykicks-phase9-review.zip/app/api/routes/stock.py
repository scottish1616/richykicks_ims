import uuid

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app.api.deps import get_current_active_user, get_db, require_admin, require_any_role
from app.core.csrf import verify_csrf
from app.models.stock_receiving import StockReceivingItem, StockReceivingSession
from app.models.user import User
from app.schemas.stock_receiving import (
    ReceivingItemCorrection,
    ReceivingItemCreate,
    ReceivingItemRead,
    ReceivingSessionRead,
)
from app.services import receiving_service as svc

router = APIRouter(prefix="/api/stock", tags=["stock-receiving"])


@router.post(
    "/sessions",
    response_model=ReceivingSessionRead,
    dependencies=[Depends(require_admin), Depends(verify_csrf)],
)
def open_session(user: User = Depends(require_admin), db: Session = Depends(get_db)):
    return svc.open_session(db, admin_id=user.id)


@router.get(
    "/sessions", response_model=list[ReceivingSessionRead], dependencies=[Depends(require_any_role)]
)
def list_sessions(db: Session = Depends(get_db)):
    return db.query(StockReceivingSession).order_by(StockReceivingSession.opened_at.desc()).all()


@router.get(
    "/sessions/{session_id}/items",
    response_model=list[ReceivingItemRead],
    dependencies=[Depends(require_any_role)],
)
def list_session_items(session_id: uuid.UUID, db: Session = Depends(get_db)):
    return db.query(StockReceivingItem).filter(StockReceivingItem.session_id == session_id).all()


@router.post(
    "/sessions/{session_id}/items",
    response_model=ReceivingItemRead,
    dependencies=[Depends(require_any_role), Depends(verify_csrf)],
)
def submit_item(
    session_id: uuid.UUID,
    payload: ReceivingItemCreate,
    user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    try:
        return svc.submit_item(
            db=db,
            session_id=session_id,
            staff_id=user.id,
            product_id=payload.product_id,
            quantity_submitted=payload.quantity_submitted,
            price_submitted=payload.price_submitted,
        )
    except svc.SessionNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    except svc.SessionNotOpenError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Session is not open")


@router.post(
    "/sessions/{session_id}/submit",
    response_model=ReceivingSessionRead,
    dependencies=[Depends(require_any_role), Depends(verify_csrf)],
)
def submit_session(
    session_id: uuid.UUID,
    user: User = Depends(get_current_active_user),
    db: Session = Depends(get_db),
):
    try:
        return svc.submit_session(db, session_id, actor_id=user.id)
    except svc.SessionNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    except svc.SessionNotOpenError:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Session is not open")
    except svc.EmptySessionError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Cannot submit an empty session"
        )


@router.patch(
    "/items/{item_id}/correct",
    response_model=ReceivingItemRead,
    dependencies=[Depends(require_admin), Depends(verify_csrf)],
)
def correct_item(
    item_id: uuid.UUID,
    payload: ReceivingItemCorrection,
    user: User = Depends(require_admin),
    db: Session = Depends(get_db),
):
    try:
        return svc.correct_item(
            db=db,
            item_id=item_id,
            quantity_approved=payload.quantity_approved,
            price_approved=payload.price_approved,
            actor_id=user.id,
        )
    except svc.ItemNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    except svc.SessionNotPendingError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Session is not pending verification"
        )


@router.post(
    "/sessions/{session_id}/approve",
    response_model=ReceivingSessionRead,
    dependencies=[Depends(require_admin), Depends(verify_csrf)],
)
def approve_session(
    session_id: uuid.UUID, user: User = Depends(require_admin), db: Session = Depends(get_db)
):
    try:
        return svc.approve_session(db, session_id, actor_id=user.id)
    except svc.SessionNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    except svc.SessionNotPendingError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Session already finalized or not pending"
        )


@router.post(
    "/sessions/{session_id}/reject",
    response_model=ReceivingSessionRead,
    dependencies=[Depends(require_admin), Depends(verify_csrf)],
)
def reject_session(
    session_id: uuid.UUID, user: User = Depends(require_admin), db: Session = Depends(get_db)
):
    try:
        return svc.reject_session(db, session_id, actor_id=user.id)
    except svc.SessionNotFoundError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    except svc.SessionNotPendingError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Session already finalized or not pending"
        )
