"""
Stock receiving models implementing the approval workflow (PRD section
10): Admin opens a session -> Staff submits items -> Admin
reviews/corrects -> Admin approves or rejects. Authoritative inventory
is only touched on approval (handled transactionally in
services/receiving_service.py, not here).
"""
import enum
import uuid
from datetime import datetime

from sqlalchemy import Integer, Numeric, DateTime, ForeignKey, Enum, CheckConstraint, func
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.core.database import Base


class ReceivingSessionStatus(str, enum.Enum):
    OPEN = "open"
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class ReceivingItemStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class StockReceivingSession(Base):
    __tablename__ = "stock_receiving_sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    opened_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=False
    )
    status: Mapped[ReceivingSessionStatus] = mapped_column(
        Enum(ReceivingSessionStatus), nullable=False, default=ReceivingSessionStatus.OPEN
    )
    opened_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
    closed_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    items: Mapped[list["StockReceivingItem"]] = relationship(back_populates="session")


class StockReceivingItem(Base):
    __tablename__ = "stock_receiving_items"
    __table_args__ = (
        CheckConstraint("quantity_submitted > 0", name="ck_receiving_qty_submitted_positive"),
        CheckConstraint(
            "quantity_approved IS NULL OR quantity_approved >= 0",
            name="ck_receiving_qty_approved_non_negative",
        ),
    )

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("stock_receiving_sessions.id"), nullable=False, index=True
    )
    product_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("products.id"), nullable=False, index=True
    )
    submitted_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id"), nullable=False
    )

    quantity_submitted: Mapped[int] = mapped_column(Integer, nullable=False)
    price_submitted: Mapped[float] = mapped_column(Numeric(10, 2), nullable=False)

    quantity_approved: Mapped[int | None] = mapped_column(Integer, nullable=True)
    price_approved: Mapped[float | None] = mapped_column(Numeric(10, 2), nullable=True)

    status: Mapped[ReceivingItemStatus] = mapped_column(
        Enum(ReceivingItemStatus), nullable=False, default=ReceivingItemStatus.PENDING
    )

    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())

    session: Mapped["StockReceivingSession"] = relationship(back_populates="items")
